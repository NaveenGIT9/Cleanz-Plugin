import { SfCommand } from '@salesforce/sf-plugins-core';
export declare function formatXml(xml: string): string;
export declare function getRootNodeName(xmlContent: string): string;
export declare function buildAsciiTable(headers: string[], rows: string[][], maxColWidths?: number[]): string;
export declare function removeXmlBlock(xmlContent: string, blockTag: string, keyTag: string, missingName: string): {
    updated: string;
    removed: boolean;
    fixed?: boolean;
};
export declare function removeProfileActionOverridesWithMissingObject(xmlContent: string, existingObjects: Set<string>, whitelistedObjects: string[]): {
    updated: string;
    removedObjects: string[];
};
export declare function removeProfileActionOverridesWithMissingRecordType(xmlContent: string, existingRecordTypes: Set<string>, whitelistedRecordTypes: string[]): {
    updated: string;
    removedRecordTypes: string[];
};
export declare function removeColumnFromReportType(xmlContent: string, fieldName: string, objectName?: string): {
    updated: string;
    removed: boolean;
};
export declare function removeJoinFromReportType(xmlContent: string, relationshipName: string): {
    updated: string;
    removed: boolean;
};
/**
 * Removes duplicate <permissionSets> lines from a PSG file in-place.
 * Does NOT reorder or relocate any lines — preserves original position so
 * git blame stays clean and tracing commits remains straightforward.
 * Only the second (and further) occurrences of a duplicate name are removed.
 */
export declare function removeDuplicatePsgPermissionSets(xmlContent: string): {
    updated: string;
    removed: string[];
};
export declare function fixPsgPermissionSetsBlock(xmlContent: string): {
    updated: string;
    fixed: boolean;
};
export declare function removeCustomButtonEntry(xmlContent: string, bareButtonName: string): {
    updated: string;
    removed: boolean;
};
export declare function maskProfileFalsePositives(xmlContent: string, isFull?: boolean): string;
export declare function maskPermSetFalsePositives(xmlContent: string, isFull?: boolean): string;
export declare function deduplicateXmlBlocks(xmlContent: string): {
    updated: string;
    removedCount: number;
};
export declare function fixMalformedXmlTags(xmlContent: string): {
    updated: string;
    fixedCount: number;
};
export default class DeployAndFix extends SfCommand<void> {
    static readonly summary: string;
    static readonly description: string;
    static readonly examples: string[];
    static readonly flags: {
        'json-path': import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        'target-org': import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        verbose: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        'dry-run': import("@oclif/core/interfaces").BooleanFlag<boolean>;
    };
    run(): Promise<void>;
}
